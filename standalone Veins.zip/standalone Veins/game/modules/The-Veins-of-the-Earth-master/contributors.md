Underdark
=========

Just fork the repo, make your changes and then make a pull request back. There's a list of issues (bugs and ideas) available on Git.

DO NOT include anything that's not OGL - for example, no illithids or kuo-toa.

Anything that's OGL - SRD, for example, Incursion, or the D&D Wiki portions marked as Open Game Content - is fine.

Any contributors will be credited in the Readme.