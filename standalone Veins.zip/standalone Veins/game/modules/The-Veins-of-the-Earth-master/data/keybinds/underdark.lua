defineAction{
	default = { "sym:_b:false:false:false:false" },
	type = "OPEN_SPELLBOOK",
	group = "actions",
	name = "Open Spellbook",
}

defineAction{
	default = { "sym:_h:false:false:false:false" },
	type = "SHOW_HELP",
	group = "actions",
	name = "Open help screen",
}