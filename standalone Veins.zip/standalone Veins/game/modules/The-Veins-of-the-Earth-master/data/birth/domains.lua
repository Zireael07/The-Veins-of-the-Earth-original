newBirthDescriptor {
  	type = 'domains',
  	name = 'Blood',
  	desc = [[Blood.]],
  	descriptor_choices =
	{
	    domains =
	    {
	      Blood = "forbid",
	    }
	},
	talents_types = {
		["domains/blood"] = {true, 0.0},
  },
}

newBirthDescriptor {
  	type = 'domains',
  	name = 'Nature',
  	desc = [[Nature.]],
  	descriptor_choices =
  	{
	 	domains =
	    {
	      Nature = "forbid",
	    }
	},
	talents_types = {
		["domains/nature"] = {true, 0.0},
  },
}

newBirthDescriptor {
  	type = 'domains',
  	name = 'Good',
  	desc = [[Good.]],
  	descriptor_choices =
  	{
	    domains =
	    {
	      Good = "forbid",
	    }
	},
	talents_types = {
		["domains/good"] = {true, 0.0},
  },
}	