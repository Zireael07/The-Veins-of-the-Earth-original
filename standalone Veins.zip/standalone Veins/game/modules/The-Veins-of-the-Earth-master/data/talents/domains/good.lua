newTalentType{ passive=true, type="domains/good", name="good", description="Good Domain" }

newTalent{
	name = "Good!!!",
	type = {"domains/good", 1},
	mode = 'passive',
	points = 1,
	is_feat = true,

	info = [[You wouldnt hurt a fly!!.]],
}