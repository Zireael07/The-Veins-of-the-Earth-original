newTalentType{ passive=true, type="domains/nature", name="nature", description="Nature Domain" }

newTalent{
	name = "Nature!!!",
	type = {"domains/nature", 1},
	mode = 'passive',
	points = 1,
	is_feat = true,

	info = [[You treehugger!.]],
}