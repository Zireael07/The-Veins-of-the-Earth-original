load("data/talents/domains/blood.lua")
load("data/talents/domains/nature.lua")
load("data/talents/domains/good.lua")