load("/data/general/npcs/humanoid.lua")

load("/data/general/npcs/undead.lua")

load("/data/general/npcs/animals.lua")
