
module("moonscript.version", package.seeall)

version = "0.2.0-dev"
function print_version()
	print("MoonScript version "..version)
end
